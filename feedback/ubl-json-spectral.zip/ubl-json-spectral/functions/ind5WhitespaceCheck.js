/**
 * UBL 2.5 IND5 (whitespace) — No whitespace-only string values
 *
 * Source rule (UBL-DocumentConstraints-2.5.patterns.sch):
 *   context="*[not(*)]"  assert: normalize-space(.)
 *   context="@*[normalize-space(.)='']"  assert: normalize-space(.)
 *
 * Scope: the three cases NOT already caught by JSON Schema's minLength:1 —
 *   1. Scalar string BBIE:               "Note": "   "
 *   2. Object-form BBIE value property:  "Note": { "value": "   " }
 *   3. Supplementary component:          "Amount": { "value": 10, "currencyID": "   " }
 *
 * Null and empty-string ("") are already rejected by JSON Schema (type + minLength:1)
 * so this function only needs to check typeof === "string" && trim() === "".
 *
 * UBLExtensions is exempt — mirrors the ext:* / ext:*//* exclusion in the XML rule.
 *
 * @param {*} doc - the entire document object (given: "$")
 * @returns array of errors, or undefined if valid
 */
export default function ind5WhitespaceCheck(doc) {
  const errors = [];

  function walk(val, path) {
    if (typeof val === "string") {
      if (val.trim() === "") {
        errors.push({ message: `[IND5] Whitespace-only string at ${path}`, path });
      }
      return;
    }

    if (Array.isArray(val)) {
      val.forEach((item, i) => walk(item, `${path}[${i}]`));
      return;
    }

    if (val !== null && typeof val === "object") {
      for (const [key, child] of Object.entries(val)) {
        if (key === "UBLExtensions") continue;  // exempt — arbitrary extension content
        walk(child, `${path}.${key}`);
      }
    }
    // booleans and numbers are never whitespace-only — no check needed
  }

  walk(doc, "$");
  return errors.length ? errors : undefined;
}

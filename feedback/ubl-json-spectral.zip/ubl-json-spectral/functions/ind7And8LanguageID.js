/**
 * UBL 2.5 IND7 + IND8 — languageID rules on Text.Type / Name.Type arrays
 *
 * Source rules (UBL-DocumentConstraints-2.5.patterns.sch):
 *
 *   [IND7] No two sibling Text.Type elements of the same name may share the same languageID value.
 *   [IND8] Where two or more sibling Text.Type elements of the same name exist,
 *          none may omit the languageID attribute.
 *
 * JSON translation:
 *   Multiple values for the same Text.Type property are expressed as an array:
 *     "Note": [
 *       { "value": "Note in English", "languageID": "en" },
 *       { "value": "Notitie in Nederlands", "languageID": "nl" }
 *     ]
 *   A single value (scalar string or single-item array) does not require languageID.
 *   IND7 and IND8 only apply when the array has 2 or more items.
 *
 * TEXT-TYPE BBIE DISCOVERY:
 *   The set of Text.Type / Name.Type BBIEs is derived at module load time by walking
 *   the UBL JSON schema chain via the spec's own catalog.json:
 *
 *     catalog.json  →  URN-to-file mapping (relative to catalog location)
 *         ↓
 *     UnqualifiedDataTypes  →  types whose object variant has a "languageID" property
 *         ↑ $ref
 *     QualifiedDataTypes    →  types that resolve to those UDT types
 *         ↑ $ref
 *     CommonBasicComponents →  BBIEs that resolve to those QDT types  ← TEXT_TYPE_BBIES
 *
 * CONFIGURATION:
 *   Pass the catalog path via functionOptions in the ruleset YAML:
 *
 *     then:
 *       function: ind7And8LanguageID
 *       functionOptions:
 *         catalog: "./schemas/catalog.json"
 *
 *   Paths in the catalog are resolved relative to the catalog file itself,
 *   matching the convention used by the UBL JSON spec.
 *   The catalog is the spec's own artifact — when OASIS publishes the final
 *   schemas, update the catalog path (or its contents) only. No code changes needed.
 *
 * UBLExtensions is exempt at every nesting level — mirrors ext:* exclusion in XML.
 */

import { readFileSync } from "fs";
import { resolve, dirname } from "path";

const UDT_URN = "urn:oasis:names:specification:ubl:schema:json:UnqualifiedDataTypes-2";
const QDT_URN = "urn:oasis:names:specification:ubl:schema:json:QualifiedDataTypes-2";
const CBC_URN = "urn:oasis:names:specification:ubl:schema:json:CommonBasicComponents-2";

/**
 * Load a schema by URN using the catalog.
 * Paths in the catalog are relative to the catalog file's own directory.
 */
function loadByUrn(urn, catalog, catalogDir) {
  const relativePath = catalog[urn];
  if (!relativePath) {
    throw new Error(`[ind7And8LanguageID] URN not found in catalog: ${urn}`);
  }
  const fullPath = resolve(catalogDir, relativePath);
  return JSON.parse(readFileSync(fullPath, "utf8"));
}

/**
 * Derive the set of Text.Type / Name.Type BBIE names by walking the schema chain.
 * Called once at module load time per unique catalog path.
 */
function deriveTextTypeBBIEs(catalogPath) {
  const catalog = JSON.parse(readFileSync(catalogPath, "utf8"));
  const catalogDir = dirname(catalogPath);

  const udt = loadByUrn(UDT_URN, catalog, catalogDir);
  const qdt = loadByUrn(QDT_URN, catalog, catalogDir);
  const cbc = loadByUrn(CBC_URN, catalog, catalogDir);

  // Step 1 — UDT types whose object variant carries a "languageID" property
  const udtTextTypes = new Set(
    Object.entries(udt["$defs"] ?? {})
      .filter(([, def]) =>
        (def.oneOf ?? []).some((variant) => variant.properties?.languageID !== undefined)
      )
      .map(([name]) => name)
  );

  // Step 2 — QDT types that $ref to one of those UDT types
  const qdtTextTypes = new Set(
    Object.entries(qdt["$defs"] ?? {})
      .filter(([, def]) => {
        const ref = def["$ref"] ?? "";
        return ref.startsWith(UDT_URN) && udtTextTypes.has(ref.split("/$defs/").at(-1));
      })
      .map(([name]) => name)
  );

  // Step 3 — CBC BBIEs that $ref to one of those QDT types
  return new Set(
    Object.entries(cbc["$defs"] ?? {})
      .filter(([, def]) => {
        const ref = def["$ref"] ?? "";
        return ref.startsWith(QDT_URN) && qdtTextTypes.has(ref.split("/$defs/").at(-1));
      })
      .map(([name]) => name)
  );
}

// Cache derivations by catalog path — safe for multi-ruleset Spectral runs
const cache = new Map();

function getTextTypeBBIEs(catalogPath) {
  if (!cache.has(catalogPath)) {
    cache.set(catalogPath, deriveTextTypeBBIEs(catalogPath));
  }
  return cache.get(catalogPath);
}

// ---------------------------------------------------------------------------
// Validation function
// ---------------------------------------------------------------------------
export default function ind7And8LanguageID(doc, _context, options) {
  const catalogPath = options?.catalog;
  if (!catalogPath) {
    throw new Error(
      "[ind7And8LanguageID] functionOptions.catalog is required — " +
      "provide the path to the UBL JSON catalog.json"
    );
  }

  const TEXT_TYPE_BBIES = getTextTypeBBIEs(catalogPath);
  const errors = [];

  function checkObject(obj, path) {
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return;

    for (const [key, val] of Object.entries(obj)) {
      if (key === "UBLExtensions") continue;

      const fieldPath = `${path}.${key}`;

      if (TEXT_TYPE_BBIES.has(key) && Array.isArray(val) && val.length > 1) {

        // IND7 — no two items may share the same languageID
        const seen = new Map();
        val.forEach((item, i) => {
          if (item && typeof item === "object" && item.languageID !== undefined) {
            const lang = item.languageID;
            if (seen.has(lang)) {
              errors.push({
                message: `[IND7] ${fieldPath}[${i}] has duplicate languageID "${lang}" (also at index ${seen.get(lang)})`,
                path: fieldPath,
              });
            } else {
              seen.set(lang, i);
            }
          }
        });

        // IND8 — when 2+ items exist, every item must carry languageID
        val.forEach((item, i) => {
          if (!item || typeof item !== "object" || item.languageID === undefined) {
            errors.push({
              message: `[IND8] ${fieldPath}[${i}] must include languageID when multiple values exist`,
              path: fieldPath,
            });
          }
        });
      }

      // Recurse into nested structures regardless of whether IND7/8 fired above
      if (Array.isArray(val)) {
        val.forEach((item, i) => checkObject(item, `${fieldPath}[${i}]`));
      } else if (val && typeof val === "object") {
        checkObject(val, fieldPath);
      }
    }
  }

  checkObject(doc, "$");
  return errors.length > 0 ? errors : undefined;
}

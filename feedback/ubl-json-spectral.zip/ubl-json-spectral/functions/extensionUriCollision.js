/**
 * UBL 2.5 — Gap 4: ExtensionURI must not collide with predefined UBL property names (§6.3)
 *
 * Spec: "This value shall not collide with any predefined UBL property name.
 *        Extension identifiers should be namespaced, for example by reverse-DNS
 *        or URI-scoped conventions, to minimize the risk of collision."
 * Gap: The JSON schema cannot express cross-field uniqueness constraints of this
 *      kind — it has no mechanism to compare a string value against a set of
 *      property names defined elsewhere in the schema.
 *
 * The full set of predefined UBL property names is derived at module load time
 * from the CommonAggregateComponents schema: all property names that appear
 * across the 310 ABIEs are collected into a Set. This includes both ABIE-level
 * property names and the CBC BBIE names they reference.
 *
 * UBLExtensions can appear at any nesting level — the walk is fully recursive.
 * Only the ExtensionURI of each UBLExtension item is checked; the content of
 * ExtensionContent is not inspected (it is exempt from all UBL constraints).
 */

import { readFileSync } from "fs";
import { resolve, dirname } from "path";

const CAC_URN = "urn:oasis:names:specification:ubl:schema:json:CommonAggregateComponents-2";

function loadByUrn(urn, catalog, catalogDir) {
  const rel = catalog[urn];
  if (!rel) throw new Error(`[extensionUriCollision] URN not in catalog: ${urn}`);
  return JSON.parse(readFileSync(resolve(catalogDir, rel), "utf8"));
}

function deriveUblPropertyNames(catalogPath) {
  const catalog = JSON.parse(readFileSync(catalogPath, "utf8"));
  const catalogDir = dirname(catalogPath);
  const cac = loadByUrn(CAC_URN, catalog, catalogDir);

  // Collect every property name used across all 310 ABIEs
  const names = new Set();
  for (const defn of Object.values(cac["$defs"] ?? {})) {
    for (const propName of Object.keys(defn.properties ?? {})) {
      names.add(propName);
    }
  }
  return names;
}

const cache = new Map();
function getUblPropertyNames(catalogPath) {
  if (!cache.has(catalogPath)) {
    cache.set(catalogPath, deriveUblPropertyNames(catalogPath));
  }
  return cache.get(catalogPath);
}

export default function extensionUriCollision(doc, _context, options) {
  const catalogPath = options?.catalog;
  if (!catalogPath) {
    throw new Error(
      "[extensionUriCollision] functionOptions.catalog is required"
    );
  }

  const UBL_PROP_NAMES = getUblPropertyNames(catalogPath);
  const errors = [];

  function walkExtensions(extensions, parentPath) {
    if (!Array.isArray(extensions)) return;
    extensions.forEach((ext, i) => {
      if (!ext || typeof ext !== "object") return;
      const extPath = `${parentPath}[${i}]`;
      const uri = ext.ExtensionURI;
      if (typeof uri === "string" && UBL_PROP_NAMES.has(uri)) {
        errors.push({
          message: `[§6.3] ${extPath}.ExtensionURI "${uri}" collides with a predefined UBL property name`,
          path: extPath,
        });
      }
    });
  }

  function walk(val, path) {
    if (!val || typeof val !== "object" || Array.isArray(val)) return;

    for (const [key, child] of Object.entries(val)) {
      const childPath = `${path}.${key}`;

      if (key === "UBLExtensions") {
        walkExtensions(child, childPath);
        // Do NOT recurse into extension content — it is exempt
      } else if (Array.isArray(child)) {
        child.forEach((item, i) => walk(item, `${childPath}[${i}]`));
      } else if (child && typeof child === "object") {
        walk(child, childPath);
      }
    }
  }

  walk(doc, "$");
  return errors.length ? errors : undefined;
}

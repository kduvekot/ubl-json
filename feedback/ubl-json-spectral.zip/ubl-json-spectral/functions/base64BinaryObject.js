/**
 * UBL 2.5 — Gap 3: BinaryObject.value must be valid base64 (§10.2)
 *
 * Spec: "The value property is required and shall contain a base64-encoded string."
 * Gap: The JSON schema only enforces type:string and minLength:1 on the value
 *      property — any non-empty string passes. A content check is needed.
 *
 * BinaryObject BBIE names are derived at module load time from the schema chain:
 *   UnqualifiedDataTypes  →  BinaryObjectType (has mimeCode in object variant)
 *       ↑ $ref
 *   QualifiedDataTypes    →  types referencing BinaryObjectType
 *       ↑ $ref
 *   CommonBasicComponents →  BBIEs referencing those types  ← BO_BBIES
 *
 * Detection: A BinaryObject instance is always in object form with a required
 * mimeCode property — using the schema-derived BBIE name set gives precision
 * and avoids false positives from arbitrary extension content (which is exempt).
 *
 * Base64 alphabet (RFC 4648 §4): A-Z a-z 0-9 + / with = padding.
 * Pattern allows: optional groups of 4 chars, optional 1-3 char final group with
 * correct padding, and empty string (already rejected upstream by minLength:1).
 *
 * UBLExtensions is exempt — extension content may freely contain any structure.
 */

import { readFileSync } from "fs";
import { resolve, dirname } from "path";

const UDT_URN = "urn:oasis:names:specification:ubl:schema:json:UnqualifiedDataTypes-2";
const QDT_URN = "urn:oasis:names:specification:ubl:schema:json:QualifiedDataTypes-2";
const CBC_URN = "urn:oasis:names:specification:ubl:schema:json:CommonBasicComponents-2";

const BASE64_RE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{4})?$/;

function loadByUrn(urn, catalog, catalogDir) {
  const rel = catalog[urn];
  if (!rel) throw new Error(`[base64BinaryObject] URN not in catalog: ${urn}`);
  return JSON.parse(readFileSync(resolve(catalogDir, rel), "utf8"));
}

function deriveBinaryObjectBBIEs(catalogPath) {
  const catalog = JSON.parse(readFileSync(catalogPath, "utf8"));
  const catalogDir = dirname(catalogPath);

  const udt = loadByUrn(UDT_URN, catalog, catalogDir);
  const qdt = loadByUrn(QDT_URN, catalog, catalogDir);
  const cbc = loadByUrn(CBC_URN, catalog, catalogDir);

  // Step 1 — UDT types with a mimeCode supplementary component
  const udtBoTypes = new Set(
    Object.entries(udt["$defs"] ?? {})
      .filter(([, d]) => (d.oneOf ?? [d]).some(v => v.properties?.mimeCode !== undefined)
        || d.properties?.mimeCode !== undefined)
      .map(([n]) => n)
  );

  // Step 2 — QDT types referencing those UDT types
  const qdtBoTypes = new Set(
    Object.entries(qdt["$defs"] ?? {})
      .filter(([, d]) => {
        const ref = d["$ref"] ?? "";
        return ref.startsWith(UDT_URN) && udtBoTypes.has(ref.split("/$defs/").at(-1));
      })
      .map(([n]) => n)
  );

  // Step 3 — CBC BBIEs referencing those QDT types
  return new Set(
    Object.entries(cbc["$defs"] ?? {})
      .filter(([, d]) => {
        const ref = d["$ref"] ?? "";
        return ref.startsWith(QDT_URN) && qdtBoTypes.has(ref.split("/$defs/").at(-1));
      })
      .map(([n]) => n)
  );
}

const cache = new Map();
function getBinaryObjectBBIEs(catalogPath) {
  if (!cache.has(catalogPath)) {
    cache.set(catalogPath, deriveBinaryObjectBBIEs(catalogPath));
  }
  return cache.get(catalogPath);
}

export default function base64BinaryObject(doc, _context, options) {
  const catalogPath = options?.catalog;
  if (!catalogPath) {
    throw new Error(
      "[base64BinaryObject] functionOptions.catalog is required"
    );
  }

  const BO_BBIES = getBinaryObjectBBIEs(catalogPath);
  const errors = [];

  function walk(val, path) {
    if (!val || typeof val !== "object" || Array.isArray(val)) return;

    for (const [key, child] of Object.entries(val)) {
      if (key === "UBLExtensions") continue;

      const childPath = `${path}.${key}`;

      if (BO_BBIES.has(key)) {
        // BinaryObject is always object form — check .value is valid base64
        if (child && typeof child === "object" && !Array.isArray(child)) {
          const v = child.value;
          if (typeof v === "string" && !BASE64_RE.test(v)) {
            errors.push({
              message: `[§10.2] ${childPath}.value must be a valid base64-encoded string`,
              path: childPath,
            });
          }
        }
      } else if (Array.isArray(child)) {
        child.forEach((item, i) => walk(item, `${childPath}[${i}]`));
      } else if (child && typeof child === "object") {
        walk(child, childPath);
      }
    }
  }

  walk(doc, "$");
  return errors.length ? errors : undefined;
}

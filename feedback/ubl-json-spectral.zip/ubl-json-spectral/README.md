# UBL 2.5 JSON — Spectral Validation Ruleset

A [Spectral](https://stoplight.io/open-source/spectral) ruleset that enforces
normative constraints from the **UBL 2.5 JSON Syntax Binding** specification
that are not already covered by JSON Schema validation.

Spec reference (draft): <https://kduvekot.github.io/ubl-json/zWMqu>  
Spec source repository: <https://github.com/kduvekot/ubl-json>

> **Status:** Work in progress — implements the complete set of gaps identified
> between the spec and JSON Schema as of the draft reviewed in March 2026.
> Not yet run against a live Spectral install; the test runner exists but has
> not been executed end-to-end. See [Next steps](#next-steps).

---

## Background

UBL 2.5 is being published with a normative JSON syntax binding alongside the
existing XML binding. The JSON binding ships with JSON Schemas that enforce most
structural constraints automatically. However, a systematic review of the spec
identified seven constraint categories that JSON Schema cannot express and that
therefore require supplementary validation — this ruleset provides that.

The original UBL XML binding used ISO Schematron (`.sch` files) for the same
purpose. The rules here are the JSON equivalent: they are specifically scoped to
the gaps, not a reimplementation of constraints the schemas already cover.

---

## What JSON Schema already handles

The normative JSON Schemas (published in `json/schemas/` in the UBL distribution)
already enforce the following, so this ruleset deliberately does **not** re-check them:

| Constraint | Mechanism |
|---|---|
| Unknown properties rejected | `additionalProperties: false` on all ABIEs and documents |
| Required properties present | `required: [...]` arrays |
| Null values rejected | `type` constraints (no `null` in any union) |
| Empty strings rejected | `minLength: 1` on all string-typed properties |
| Empty objects rejected | `minProperties: 1` on object-typed properties |
| Date/time format | Regex `pattern` on DateType and TimeType |
| BinaryObject has `value` + `mimeCode` | `required` on BinaryObjectType |
| Extensions require `ExtensionURI` + `ExtensionContent` | `required` on UBLExtensionType |
| `$jsonschema` required and correct on **document** instances | `required` + `const` on every document schema |

---

## What this ruleset adds

Seven rules covering the remaining normative gaps:

| Rule ID | Spec section | What it checks |
|---|---|---|
| `ubl-IND5-IND9-no-whitespace-strings` | §7.4 | Whitespace-only strings (`"   "`) that pass `minLength:1` but violate `normalize-space()` semantics |
| `ubl-IND7-IND8-languageID` | §7.4 | Duplicate `languageID` values in Text.Type arrays (IND7); missing `languageID` when 2+ items exist (IND8) |
| `ubl-jsonschema-required` | §9.1 | `$jsonschema` absent from root of standalone ABIE payloads (document schemas already enforce this; all 310 ABIEs do not) |
| `ubl-extension-jsonschema-required` | §9.1 | `$jsonschema` absent from a `UBLExtensions` item — the `UBLExtensionType` schema defines no such property at all |
| `ubl-base64-binary-object` | §10.2 | `EmbeddedDocumentBinaryObject.value` or `ResponseBinaryObject.value` is not valid RFC 4648 base64 |
| `ubl-extension-uri-no-collision` | §6.3 | `ExtensionURI` value matches a predefined UBL property name (1 786 names derived from the CAC schema) |

### Rule details

#### IND5 / IND9 — Whitespace-only strings

The JSON Schema `minLength: 1` constraint rejects empty strings (`""`) but
accepts strings composed entirely of whitespace (`"   "`), because it counts
characters, not meaningful content. The original XML Schematron rule used
`normalize-space()` to catch this. This rule is the JSON equivalent.

Three cases are covered:
- Scalar BBIE: `"Note": "   "`
- Object-form `.value`: `"Note": { "value": "   " }`
- Supplementary component: `"Amount": { "value": 100, "currencyID": "   " }`

`UBLExtensions` content is exempt at every nesting level, matching the
`ext:* / ext:*//*` exclusion in the original Schematron rule.

#### IND7 / IND8 — languageID on Text.Type arrays

In UBL JSON, multiple values of the same Text.Type or Name.Type field are
expressed as an array:

```json
"Note": [
  { "value": "Payment within 30 days", "languageID": "en" },
  { "value": "Betaling binnen 30 dagen", "languageID": "nl" }
]
```

- **IND7**: No two items in such an array may share the same `languageID`.
- **IND8**: When an array has two or more items, every item must carry `languageID`.

Single-value fields — whether a plain scalar string or a single-item array —
are exempt from both rules.

The set of Text.Type and Name.Type BBIEs (277 fields) is **derived at module
load time** from the UBL schema chain via `catalog.json`. There is no hardcoded
list; upgrading to a new UBL version requires no code changes.

#### Gap 1 — `$jsonschema` on standalone ABIEs

The spec (§9.1) requires every conformant UBL JSON instance to carry a
`$jsonschema` property at its root. All 101 document schemas enforce this via
their `required` array. However, all 310 ABIE definitions in
`CommonAggregateComponents-2.5.json` define `$jsonschema` as a property with
the correct `const` value, but omit it from `required`. A standalone
`AddressType` payload without `$jsonschema` therefore passes JSON Schema
validation but violates the spec.

The expected value format for standalone ABIEs is:
```
urn:oasis:names:specification:ubl:schema:json:CommonAggregateComponents-2#<TypeName>
```

#### Gap 2 — `$jsonschema` on extension containers

The spec (§9.1) requires each `UBLExtension` item to include a `$jsonschema`
property identifying the schema governing its content. The `UBLExtensionType`
schema in `CommonExtensionComponents-2.5.json` defines no `$jsonschema`
property at all — not optional, not required, simply absent. `UBLExtensions`
can appear at any nesting level; the Spectral path `$..UBLExtensions[*]`
matches all of them recursively.

#### Gap 3 — BinaryObject base64 validation

The spec (§10.2) states that `BinaryObject.value` *"shall contain a
base64-encoded string"*. The JSON Schema only enforces `type: string` and
`minLength: 1`, so any non-empty string passes. This rule validates the value
against the RFC 4648 base64 alphabet (`A-Z a-z 0-9 + /` with `=` padding).

Only two BBIEs in the entire UBL library are typed as `BinaryObjectType`:
`EmbeddedDocumentBinaryObject` (in `AttachmentType`) and
`ResponseBinaryObject` (in `ResponseValueType`). Both are derived from the
schema chain at load time.

#### Gap 4 — ExtensionURI collision

The spec (§6.3) states that `ExtensionURI` *"shall not collide with any
predefined UBL property name"* and recommends namespaced URIs
(e.g. reverse-DNS or URI-scoped conventions). The full set of 1 786 predefined
property names is derived from `CommonAggregateComponents-2.5.json` at load
time and checked against the `ExtensionURI` of every extension item at every
nesting level.

---

## Repository structure

```
ubl-json-spectral/
│
├── ubl-2.5-ind.spectral.yaml      Main ruleset — reference this when running Spectral
│
├── functions/                      Custom Spectral functions (ES modules)
│   ├── ind5WhitespaceCheck.js      IND5/IND9 — whitespace-only string detection
│   ├── ind7And8LanguageID.js       IND7/IND8 — languageID rules on Text.Type arrays
│   ├── base64BinaryObject.js       Gap 3 — base64 validation on BinaryObject values
│   └── extensionUriCollision.js    Gap 4 — ExtensionURI vs UBL property name collision
│
├── schemas/                        Local copies of UBL JSON schemas (draft)
│   ├── catalog.json                UBL catalog — maps URNs to schema file paths
│   └── common/
│       ├── UnqualifiedDataTypes-2.5.json
│       ├── QualifiedDataTypes-2.5.json
│       ├── CommonBasicComponents-2.5.json
│       └── CommonAggregateComponents-2.5.json
│
├── tests/
│   ├── test-suite.yaml             Machine-readable test cases (27 tests, 7 rules)
│   └── runner.js                   Test runner — extracts, lints, and asserts each case
│
└── package.json
```

---

## Installation

Requires Node.js 18 or later.

```bash
npm install
```

This installs `@stoplight/spectral-cli` and `js-yaml`.

---

## Usage

### Lint a UBL JSON document

```bash
npx spectral lint path/to/invoice.json --ruleset ubl-2.5-ind.spectral.yaml
```

### Lint a standalone ABIE payload

```bash
npx spectral lint path/to/address.json --ruleset ubl-2.5-ind.spectral.yaml
```

### Run the test suite

```bash
npm test
# or with full Spectral output per test:
npm run test:verbose
# or filter to a specific rule area:
node tests/runner.js --filter gap2
node tests/runner.js --filter ind7
```

---

## Schema-driven design

Three of the four custom functions derive their working sets from the UBL schemas
at **module load time** — not at validation time, not from a hardcoded list:

```
catalog.json  →  URN-to-file mapping
    ↓
UnqualifiedDataTypes  →  types with languageID / mimeCode (TextType, NameType, BinaryObjectType)
    ↑ $ref
QualifiedDataTypes    →  qualified refinements of those types
    ↑ $ref
CommonBasicComponents →  the 277 Text/Name BBIEs, 2 BinaryObject BBIEs
    ↑ used as property names in
CommonAggregateComponents  →  1786 distinct property names (Gap 4 collision set)
```

Each derived set is cached per catalog path. The cost (reading ~1 MB of JSON,
once per `spectral lint` invocation) is negligible compared to document
validation time.

**Upgrading to a new UBL version:** replace the schema files in `schemas/common/`
and update `schemas/catalog.json` to point at the new files. No function code
changes are required.

**When OASIS publishes the final schemas:** update `functionOptions.catalog` in
`ubl-2.5-ind.spectral.yaml` to point at the official location, or at a local
download of the published package.

---

## Test suite structure

`tests/test-suite.yaml` contains 27 test cases. Each entry has:

```yaml
- name: ind7_duplicate_languageid_root
  description: >
    Two Note values at document root share the same languageID "en".
    IND7 prohibits siblings of the same element name with identical languageID.
  expect: fail                          # "pass" or "fail"
  errors:                               # only meaningful when expect: fail
    - rule: ubl-IND7-IND8-languageID   # Spectral rule ID
      path: "$.Note"                   # JSONPath where error is expected
      message: "[IND7]"                # substring that must appear in error message
  document:                            # the UBL JSON instance under test
    $jsonschema: "urn:oasis:..."
    ID: "INV-001"
    Note:
      - value: "First note"
        languageID: "en"
      - value: "Second note"
        languageID: "en"
```

The runner asserts:
- `expect: pass` → Spectral reports zero errors
- `expect: fail` → every entry in `errors[]` matches at least one actual Spectral error
  (by rule ID, path suffix, and message substring)

---

## Known limitations and next steps

### Not yet done

1. **End-to-end test run** — the runner has not been executed against a live
   Spectral install. The Spectral path format returned for custom functions
   may differ from built-in rules; the `jsonPathMatches()` helper in
   `runner.js` may need adjustment once real output is observed.

2. **Spectral function signature** — Spectral custom functions receive
   `(input, context, options)` but the exact shape of `context` (and whether
   `functionOptions` arrives as the third argument or via `context.options`)
   depends on the Spectral version. Verify against
   `@stoplight/spectral-cli@6.x` and adjust if needed.

3. **Gap 1 `$jsonschema` value validation** — the current rule only checks
   that `$jsonschema` is *present*. It does not verify that the value matches
   the correct `const` for the ABIE type being used. A follow-on rule could
   check this by looking up the declared type in the CAC schema.

4. **Controlled vocabularies (§8)** — the spec explicitly defers validation
   of `currencyID` (ISO 4217), `unitCode` (UN/ECE Rec 20/21), and country
   codes (ISO 3166) to community profiles. These are out of scope for this
   baseline ruleset but could be added as optional/warning-level rules.

5. **Digital signature structural validation (§11)** — the spec defines the
   enveloped and detached JWS profiles. Structural checks (e.g. `protected`
   and `signature` present on each JWS object) are not currently implemented.

6. **Profile support (§9.2)** — community profiles may tighten cardinalities
   or fix code list values. These would be additional rulesets that extend
   this base ruleset using Spectral's `extends` mechanism.

### Suggested first tasks for the developer

- [ ] Run `npm install && npm test` and observe actual Spectral output
- [ ] Fix any path matching issues in `runner.js` based on real output
- [ ] Confirm `functionOptions` arrives correctly in each custom function
- [ ] Add Gap 1 `$jsonschema` const validation (optional but spec-correct)
- [ ] Consider publishing as an npm package for reuse across UBL implementations

---

## Spec constraints deliberately out of scope

| Constraint | Reason |
|---|---|
| Controlled vocabulary values (ISO 4217, UN/ECE, ISO 3166) | Spec §8 explicitly defers these to community profiles |
| Profile conformance declarations (§9.2) | Profile-specific; not part of base conformance |
| Cryptographic signature validity (§11) | Algorithm and trust management are out of scope per spec |
| Out-of-band / in-band `$jsonschema` consistency | Requires knowledge of the transport or API contract |

---

## References

- UBL 2.5 JSON Syntax Binding draft: <https://kduvekot.github.io/ubl-json/zWMqu>
- UBL JSON schemas (draft): <https://kduvekot.github.io/ubl-json/zWMqu/json/schemas/>
- Spectral documentation: <https://docs.stoplight.io/docs/spectral>
- Spectral custom functions: <https://docs.stoplight.io/docs/spectral/custom-functions>
- JSON Schema draft-07 (used by UBL schemas): <https://json-schema.org/draft-07>
- RFC 4648 (base64): <https://www.rfc-editor.org/rfc/rfc4648>
- RFC 7515 (JWS): <https://www.rfc-editor.org/rfc/rfc7515>
- RFC 8785 (JCS): <https://www.rfc-editor.org/rfc/rfc8785>

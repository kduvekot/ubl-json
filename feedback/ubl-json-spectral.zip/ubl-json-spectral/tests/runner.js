#!/usr/bin/env node
/**
 * UBL 2.5 JSON Spectral Ruleset — Test Runner
 *
 * Reads tests/test-suite.yaml, extracts each document to a temporary JSON file,
 * runs Spectral against it, and asserts the expected outcome.
 *
 * Usage:
 *   node tests/runner.js [--filter <name>] [--verbose]
 *
 * Options:
 *   --filter <name>   Run only tests whose name contains <name>
 *   --verbose         Show full Spectral output for every test
 *
 * Requirements:
 *   npm install  (installs @stoplight/spectral-cli and js-yaml)
 */

import { execSync } from "child_process";
import { readFileSync, writeFileSync, mkdirSync, rmSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __dir = dirname(fileURLToPath(import.meta.url));
const root  = resolve(__dir, "..");

// ---------------------------------------------------------------------------
// Parse args
// ---------------------------------------------------------------------------
const args    = process.argv.slice(2);
const filter  = args.includes("--filter")  ? args[args.indexOf("--filter") + 1]  : null;
const verbose = args.includes("--verbose");

// ---------------------------------------------------------------------------
// Load YAML (use js-yaml if available, otherwise fail with a clear message)
// ---------------------------------------------------------------------------
let yaml;
try {
  const { load } = await import("js-yaml");
  yaml = load;
} catch {
  console.error("ERROR: js-yaml not found. Run: npm install");
  process.exit(1);
}

const suitePath = resolve(__dir, "test-suite.yaml");
const suite     = yaml(readFileSync(suitePath, "utf8"));

// ---------------------------------------------------------------------------
// Temp directory for individual document files
// ---------------------------------------------------------------------------
const tmpDir = resolve(__dir, ".tmp");
mkdirSync(tmpDir, { recursive: true });

// ---------------------------------------------------------------------------
// Run tests
// ---------------------------------------------------------------------------
let passed = 0, failed = 0, skipped = 0;
const failures = [];

for (const test of suite.tests) {
  if (filter && !test.name.includes(filter)) {
    skipped++;
    continue;
  }

  const docPath = resolve(tmpDir, `${test.name}.json`);
  writeFileSync(docPath, JSON.stringify(test.document, null, 2));

  const rulesetPath = resolve(root, "ubl-2.5-ind.spectral.yaml");

  let spectralOutput = "";
  let spectralErrors = [];

  try {
    spectralOutput = execSync(
      `npx --yes @stoplight/spectral-cli lint "${docPath}" --ruleset "${rulesetPath}" --format json`,
      { cwd: root, encoding: "utf8", stdio: ["pipe", "pipe", "pipe"] }
    );
  } catch (err) {
    // Spectral exits non-zero when it finds errors — that's expected for fail tests
    spectralOutput = err.stdout || "";
  }

  try {
    spectralErrors = JSON.parse(spectralOutput);
  } catch {
    // Spectral may print non-JSON warnings before the JSON — try to extract it
    const jsonStart = spectralOutput.indexOf("[");
    if (jsonStart !== -1) {
      try { spectralErrors = JSON.parse(spectralOutput.slice(jsonStart)); } catch { /* ignore */ }
    }
  }

  if (verbose) {
    console.log(`\n--- ${test.name} ---`);
    console.log(JSON.stringify(spectralErrors, null, 2));
  }

  let ok = true;
  const testFailures = [];

  if (test.expect === "pass") {
    if (spectralErrors.length > 0) {
      ok = false;
      testFailures.push(
        `Expected zero errors but got ${spectralErrors.length}:\n` +
        spectralErrors.map(e => `  [${e.code}] ${e.message} at ${e.path?.join(".")}`).join("\n")
      );
    }
  } else if (test.expect === "fail") {
    if (spectralErrors.length === 0) {
      ok = false;
      testFailures.push("Expected errors but Spectral reported none");
    } else {
      // Assert each expected error signature appears in actual output
      for (const expected of (test.errors ?? [])) {
        const match = spectralErrors.find(actual =>
          (!expected.rule    || actual.code === expected.rule) &&
          (!expected.message || actual.message?.includes(expected.message)) &&
          (!expected.path    || jsonPathMatches(actual, expected.path))
        );
        if (!match) {
          ok = false;
          testFailures.push(
            `Expected error not found:\n` +
            `  rule: ${expected.rule}\n` +
            `  path: ${expected.path}\n` +
            `  message contains: "${expected.message}"\n` +
            `Actual errors:\n` +
            spectralErrors.map(e => `  [${e.code}] ${e.message} at ${JSON.stringify(e.path)}`).join("\n")
          );
        }
      }
    }
  }

  const status = ok ? "✓ PASS" : "✗ FAIL";
  console.log(`${status}  ${test.name}`);
  if (!ok) {
    for (const f of testFailures) console.log(`       ${f.split("\n").join("\n       ")}`);
    failures.push({ name: test.name, description: test.description, details: testFailures });
    failed++;
  } else {
    passed++;
  }
}

// ---------------------------------------------------------------------------
// Cleanup and summary
// ---------------------------------------------------------------------------
rmSync(tmpDir, { recursive: true, force: true });

console.log(`\n${"─".repeat(60)}`);
console.log(`Results: ${passed} passed, ${failed} failed, ${skipped} skipped`);
console.log(`${"─".repeat(60)}`);

if (failures.length > 0) {
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Helper: check if a Spectral error path matches an expected JSONPath string
// Spectral returns path as an array e.g. ["Note"] or ["UBLExtensions", "0"]
// Expected paths are JSONPath strings e.g. "$.Note" or "$.UBLExtensions[0]"
// ---------------------------------------------------------------------------
function jsonPathMatches(actualError, expectedPath) {
  if (!actualError.path) return false;
  // Reconstruct JSONPath from Spectral's path array
  const reconstructed = "$." + actualError.path
    .map((seg, i) => (typeof seg === "number" || /^\d+$/.test(seg))
      ? `[${seg}]`
      : (i === 0 ? seg : `.${seg}`))
    .join("")
    .replace(/\.\[/g, "[");
  // Normalise both sides and do a suffix match (Spectral path may be relative)
  const norm = p => p.replace(/\s/g, "");
  return norm(reconstructed).endsWith(norm(expectedPath.replace(/^\$\.?/, "")));
}

#!/usr/bin/env python3

import sys
import json
from pathlib import Path
from urllib.parse import urldefrag
from referencing import Registry
from referencing.jsonschema import DRAFT202012
from jsonschema import Draft202012Validator

BASE_DIR = Path(__file__).parent
SCHEMA_ROOT = BASE_DIR / "schemas"


def build_registry():
    """Load all schemas and register by filename for $ref resolution."""
    registry = Registry()
    for schema_file in SCHEMA_ROOT.rglob("*.json"):
        with open(schema_file) as f:
            try:
                contents = json.load(f)
            except json.JSONDecodeError:
                continue
        resource = DRAFT202012.create_resource(contents)
        registry = registry.with_resource(schema_file.name, resource)
        try:
            rel = schema_file.relative_to(SCHEMA_ROOT)
            registry = registry.with_resource(str(rel), resource)
            registry = registry.with_resource(f"../{rel}", resource)
        except ValueError:
            pass
    return registry


def resolve_schema_location(ubl_entity: str):
    """Map a UBLEntity URI to a local schema filename and optional anchor."""
    uri, fragment = urldefrag(ubl_entity)
    name = Path(uri).name
    filename = f"{name}.5.json"

    if name.startswith("Common") or name.startswith("Signature") or \
            name.startswith("Qualified") or name.startswith("Unqualified"):
        rel_path = f"common/{filename}"
    else:
        rel_path = f"maindoc/{filename}"

    schema_path = SCHEMA_ROOT / rel_path
    if not schema_path.exists():
        sys.exit(f"Schema not found: {schema_path}")

    return schema_path.name, fragment


def validate_instance(instance_path: Path):
    instance = json.loads(instance_path.read_text(encoding="utf-8"))

    ubl_entity = instance.get("UBLEntity")
    if not ubl_entity:
        sys.exit("Instance missing mandatory 'UBLEntity'")

    schema_name, fragment = resolve_schema_location(ubl_entity)
    print(f"Schema file: {schema_name}")
    print(f"ABIE: {fragment or '(document)'}")

    registry = build_registry()

    ref_uri = schema_name + (f"#{fragment}" if fragment else "")
    ref_schema = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$ref": ref_uri
    }

    validator = Draft202012Validator(ref_schema, registry=registry)
    errors = sorted(validator.iter_errors(instance), key=lambda e: list(e.path))

    if errors:
        print(f"VALIDATION FAILED - {len(errors)} error(s):")
        for e in errors[:50]:
            loc = "/" + "/".join(map(str, e.path)) if e.path else "(root)"
            print(f"    {loc}: {e.message}")
        return False

    print(f"VALIDATION PASSED")
    return True


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python validate.py <json-file>")

    json_file = Path(sys.argv[1])

    validate_instance(json_file)
